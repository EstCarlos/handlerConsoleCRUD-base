# Librería que tee permite hacer un CRUD con los campos que quieras

[Por Carlos Soto De Dios](https://www.linkedin.com/in/carlos-soto-537655224/)

<br>

Esta librería que te permite crear un programa en consola que te permite hacer un CRUD y los campos son a eleccion tuya

Para utilizarlo simplemente necesitas la funcion screenHandler() en tu programa y se ejecutara

```
screenHandler()

```

<br>

## 💡 Prerequisitos

[Python 3](https://www.python.org/downloads/release/python-370/)

<br>

## 📚 Ejemplo de uso

```
from handler import screenHandler

screenHandler()
```
